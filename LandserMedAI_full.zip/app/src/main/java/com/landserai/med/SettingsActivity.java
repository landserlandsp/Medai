package com.landserai.med;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    EditText openaiKey, deepseekKey, geminiKey;
    Button saveBtn;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_settings);
        openaiKey = findViewById(R.id.openaiKey);
        deepseekKey = findViewById(R.id.deepseekKey);
        geminiKey = findViewById(R.id.geminiKey);
        saveBtn = findViewById(R.id.saveBtn);

        saveBtn.setOnClickListener(v -> {
            String a = openaiKey.getText().toString().trim();
            String d = deepseekKey.getText().toString().trim();
            String g = geminiKey.getText().toString().trim();
            getSharedPreferences("landser_prefs", MODE_PRIVATE)
                .edit()
                .putString("OPENAI_API_KEY", a)
                .putString("DEEPSEEK_API_KEY", d)
                .putString("GEMINI_API_KEY", g)
                .apply();
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
