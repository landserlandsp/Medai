package com.landserai.med;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import okhttp3.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {
    EditText inputQuery;
    TextView outputView;
    Spinner engineSpinner;
    Button sendBtn, settingsBtn;
    OkHttpClient client = new OkHttpClient();
    Gson gson = new Gson();
    ExecutorService exec = Executors.newSingleThreadExecutor();
    List<Map<String,String>> localAlgorithms = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputQuery = findViewById(R.id.inputQuery);
        outputView = findViewById(R.id.outputView);
        engineSpinner = findViewById(R.id.engineSpinner);
        sendBtn = findViewById(R.id.sendBtn);

        settingsBtn = new Button(this);
        settingsBtn.setText("Настройки");
        ((LinearLayout)findViewById(android.R.id.content)).addView(settingsBtn);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Local","ChatGPT","Gemini","DeepSeek"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        engineSpinner.setAdapter(adapter);

        loadLocalAlgorithms();

        sendBtn.setOnClickListener(v -> {
            String q = inputQuery.getText().toString().trim();
            if (q.isEmpty()) { Toast.makeText(this, "Введите запрос", Toast.LENGTH_SHORT).show(); return; }
            outputView.setText("Обработка...");
            int sel = engineSpinner.getSelectedItemPosition();
            if (sel==0) { // Local search
                String res = searchLocal(q);
                outputView.setText(res);
            } else {
                // online AI calls (simplified) - need API keys in SharedPreferences
                exec.submit(() -> {
                    String apiKey = getApiKeyFor(sel);
                    if (apiKey==null || apiKey.isEmpty()) {
                        runOnUiThread(() -> outputView.setText("API ключ не задан. Открой Настройки."));
                        return;
                    }
                    String result = callAi(sel, q, apiKey);
                    runOnUiThread(() -> outputView.setText(result));
                });
            }
        });

        settingsBtn.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    private void loadLocalAlgorithms() {
        try {
            InputStream is = getAssets().open("algorithms.json");
            int size = is.available();
            byte[] b = new byte[size];
            is.read(b);
            is.close();
            String json = new String(b, StandardCharsets.UTF_8);
            Map[] arr = gson.fromJson(json, Map[].class);
            for (Map m : arr) localAlgorithms.add(m);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String searchLocal(String q) {
        q = q.toLowerCase(Locale.ROOT);
        for (Map<String,String> m : localAlgorithms) {
            String title = m.getOrDefault("title","").toLowerCase(Locale.ROOT);
            String content = m.getOrDefault("content","").toLowerCase(Locale.ROOT);
            if (title.contains(q) || content.contains(q)) return m.get("content");
        }
        return "Не найдено в локальной базе.";
    }

    private String getApiKeyFor(int sel) {
        SharedPreferences p = getSharedPreferences("landser_prefs", MODE_PRIVATE);
        if (sel==1) return p.getString("OPENAI_API_KEY", "");
        if (sel==2) return p.getString("GEMINI_API_KEY", "");
        if (sel==3) return p.getString("DEEPSEEK_API_KEY", "");
        return "";
    }

    private String callAi(int sel, String q, String apiKey) {
        try {
            MediaType JSON = MediaType.get("application/json; charset=utf-8");
            String url = "";
            String body = "";
            if (sel==1) {
                url = "https://api.openai.com/v1/chat/completions";
                body = "{"model":"gpt-4o-mini","messages":[{"role":"user","content":""+q+""}]}";
            } else if (sel==3) {
                url = "https://api.deepseek.com/v1/chat/completions";
                body = "{"model":"deepseek-chat","messages":[{"role":"user","content":""+q+""}]}";
            } else {
                url = "https://generativelanguage.googleapis.com/v1beta2/models/chat-bison-001:generate?key="+apiKey;
                body = "{"input":{"text":""+q+""}}";
            }
            RequestBody rb = RequestBody.create(body, JSON);
            Request req = new Request.Builder().url(url).post(rb).header("Authorization","Bearer "+apiKey).build();
            try (Response resp = client.newCall(req).execute()) {
                if (!resp.isSuccessful()) return "Ошибка: " + resp.code();
                return resp.body().string();
            }
        } catch (IOException e) {
            return "Сетевая ошибка: " + e.getMessage();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exec.shutdownNow();
    }
}
